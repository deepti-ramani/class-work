# Pong
Base version is finished. Now to make it cooler. :)

Reference: https://www.youtube.com/watch?v=nxZqW14GS20
